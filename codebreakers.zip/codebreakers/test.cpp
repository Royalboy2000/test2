#include <iostream>
#include <windows.h>

bool isAdmin() {
    // Check if the program is running with admin rights by attempting to create a file in the Windows directory
    HANDLE hFile = CreateFile("C:\\Windows\\test.tmp", GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE) {
        CloseHandle(hFile);
        DeleteFile("C:\\Windows\\test.tmp");
        return true; // Admin rights detected
    } else {
        return false; // No admin rights
    }
}

int main() {
    // Ask for admin permission
    if (!isAdmin()) {
        std::cerr << "Please run the program as administrator." << std::endl;
        system("pause"); // Pause to show the error message before exiting
        return 1;
    }

    // Variables holding paths and settings
    const char* powershellPath = "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe";
    const char* scriptPath = "test.ps1"; // Assuming test.ps1 is in the same directory as the executable
    const char* executionPolicy = "Unrestricted";

    // Set execution policy
    std::string setExecutionPolicyCommand = std::string(powershellPath) + " -Command \"Set-ExecutionPolicy " + std::string(executionPolicy) + " -Scope CurrentUser -Force\"";
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcess(NULL, (LPSTR)setExecutionPolicyCommand.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        std::cerr << "Error creating process to set execution policy." << std::endl;
        return 1;
    }
    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    // Run PowerShell script in the background
    std::string runScriptCommand = std::string(powershellPath) + " -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + std::string(scriptPath) + "\"";
    if (!CreateProcess(NULL, (LPSTR)runScriptCommand.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        std::cerr << "Error creating process to run PowerShell script." << std::endl;
        return 1;
    }
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    // Wait for user input before exiting
    std::cout << "Press any key to exit..." << std::endl;
    system("pause > nul");

    return 0;
}
